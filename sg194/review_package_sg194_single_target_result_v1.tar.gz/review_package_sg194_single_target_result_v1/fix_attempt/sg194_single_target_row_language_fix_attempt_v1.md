# SG194 Single Target Row Language Fix Attempt v1

- Purpose: record the code-path change that stops publishing raw-current single results as final.

```json
{
  "generated_at": "2026-04-01T13:15:42+08:00",
  "code_changes": [
    {
      "file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
      "change": "Switch active single publication from raw-current override to target-row-language projection-contract fields."
    },
    {
      "file": "sg194/debug_workflow_portability_194.1.1.1.py",
      "change": "Expose raw-current object-language metadata explicitly for stage1 provenance."
    },
    {
      "file": "sg194/debug_sg194_single_target_row_language_fix_v1.py",
      "change": "Demote the old parity-fix entry to a compatibility wrapper."
    }
  ],
  "mechanical_findings": {
    "projected_current_matches_external_matrix_exactly": false,
    "exact_linear_target_alignment_exists": false,
    "mismatch_rank_after_projection": 1
  },
  "decision": "Promote single target-row-language result to active publication because it is computed directly in target coordinates, but keep exact current/external generator alignment as an explicit remaining blocker."
}
```
