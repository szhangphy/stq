# SG194 Double Target Object Stack v1

- Purpose: name the exact layers currently used by the active double benchmark-facing path.

```json
{
  "generated_at": "2026-04-01T13:15:42+08:00",
  "target_group": "194.1.1.1",
  "double_target_object_stack": [
    {
      "layer": 1,
      "name": "shared_k_geometry",
      "status": "available",
      "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
      "source_function": "build_shared_kgeometry",
      "artifact": "sg194/group_194_1_1_1_double_full_compatibility_with_planes.json",
      "summary": "Shared k-space geometry / incidence / endpoint ordering reused by both single and double runtime builders."
    },
    {
      "layer": 2,
      "name": "active_current_row_language",
      "status": "available",
      "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
      "source_function": "build_double_runtime",
      "artifact": "sg194/group_194_1_1_1_double_bs_analysis.json",
      "summary": "42-row current runtime shell with raw BS nullity 16 before target matching."
    },
    {
      "layer": 3,
      "name": "target_row_language_or_benchmark_target",
      "status": "available",
      "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
      "source_function": "load_double_internalization_snapshot",
      "artifact": "sg194/sg194_external_spinorial_generator_matrix.json",
      "summary": "Benchmark-facing double target object represented by the external spinorial 33-generator matrix."
    },
    {
      "layer": 4,
      "name": "current_external_generator_alignment",
      "status": "available",
      "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
      "source_function": "load_double_internalization_snapshot",
      "artifact": "sg194/sg194_double_complement_patch_summary_v1.json",
      "summary": "Exact 33-channel generator-space identity with rank record 10/10/10/10."
    },
    {
      "layer": 5,
      "name": "target_layer_ai_basis",
      "status": "available",
      "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
      "source_function": "load_double_internalization_snapshot",
      "artifact": "sg194/raw_194_1_1_1_double_ai_in_bs_matrix_patched_v2.json",
      "summary": "Current double AI basis already internalized into the benchmark target object at rank 10."
    },
    {
      "layer": 6,
      "name": "quotient_presentation",
      "status": "available",
      "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
      "source_function": "apply_double_internalization_fields",
      "artifact": "sg194/current_status_194.1.1.1_stage2.json",
      "summary": "matched_target_inference_after_exact_double_generator_space_identity"
    }
  ]
}
```
