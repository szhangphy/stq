# Review Package

## Task Scope
- Reference group: `10.4.1.31`
- Fixed target group: `194.1.1.1`
- Goal: workflow portability pilot

## Known Premises
- 10.4.1.31 single-group is already closed.
- 10.4.1.31 double-group is already closed through quotient extraction.
- This package tests how much of that workflow ports to 194.1.1.1.

## New Material In This Package
- controlled-case audit for 194.1.1.1
- single-group pilot for 194.1.1.1
- double-group pilot for 194.1.1.1
- internal honest-shell diagnostics kept separate from the publication-level C_pub builder
- full-shell automorphism diagnostics for the P1-P5 double-class resolution
- publication-shell reduction / Bilbao check / internal-vs-publication separation reports
- AI full-character alignment plus library integration / obstruction diagnosis / honest blocker reports
- P4 induction-failure, exact-solver reliability, and band-character/site-phase deep-dive reports
- setting-specific character-field basis/convention audit plus SG194-only conversion validation
- retired invalidation of the earlier fake global conversion claim
- D3h-like local-object crosscheck plus PPATH06 residual-obstruction deep-dive reports
- zero-subset rank analysis, residual quotient-rank attribution, explicit residual rank-5 pivot witnesses, AI completion feasibility from the residual sector, authoritative AI promotion, AI rank-after-promotion, publication point-basis usage, the final single-group honest quotient report, the final double-group honest quotient report, single/double indicator extraction reports, and a claim-scope guardrail report
- double benchmark-oracle SNF check and the diagnostic-kernel-vs-benchmark final-source alignment report
- group-driven engine mode reports for the SG194 benchmark-aligned positive case and the 99.1.1.1 no-oracle diagnostic-only control case
- PDF technical report
- handoff / current_status / next_step_prompt

## Current Honest Classifications
- single-group quotient: `trivial`
- double-group quotient: `Z6`
- user expectation for single: `trivial`
- workspace Bilbao-backed reference for double: `Z6`
- final double quotient source is benchmark-aligned and must remain distinct from the 42-generator diagnostic compatibility-kernel image

## Suggested Review Order
1. workflow_portability_report_194.1.1.1.pdf
2. controlled_case_audit_194.1.1.1.md
3. workflow_portability_audit_194.1.1.1.md
4. workflow_portability_summary_194.1.1.1.json
5. group_194_1_1_1_single_pilot_audit.md
6. group_194_1_1_1_double_pilot_audit.md
7. bs_fix_reaudit_v1/publication_shell_reduction_report.md
8. bs_fix_reaudit_v1/publication_shell_vs_bilbao_check.md
9. bs_fix_reaudit_v1/internal_vs_publication_object_report.md
10. bs_fix_reaudit_v1/full_shell_automorphism_search_report.md
11. bs_fix_reaudit_v1/ai_full_character_alignment_report.md
12. bs_fix_reaudit_v1/ai_obstruction_diagnosis_report.md
13. bs_fix_reaudit_v1/ai_library_integration_report.md
14. bs_fix_reaudit_v1/bs_rank_naming_fix_report.md
15. bs_fix_reaudit_v1/ai_rank_gap_attribution_report.md
16. bs_fix_reaudit_v1/ai_rank_gap_quotient_report.md
17. bs_fix_reaudit_v1/residual_rank5_pivot_witness_report.md
18. bs_fix_reaudit_v1/ai_completion_feasibility_from_residual_sector.md
19. bs_fix_reaudit_v1/authoritative_ai_promotion_report.md
20. bs_fix_reaudit_v1/ai_rank_after_promotion_report.md
21. bs_fix_reaudit_v1/publication_point_basis_usage_report.md
22. bs_fix_reaudit_v1/single_bs_ai_quotient_report.md
23. bs_fix_reaudit_v1/single_indicator_extraction_report.md
24. bs_fix_reaudit_v1/double_ai_library_integration_report.md
25. bs_fix_reaudit_v1/double_bs_ai_quotient_report.md
26. bs_fix_reaudit_v1/double_indicator_extraction_report.md
27. bs_fix_reaudit_v1/double_benchmark_oracle_orientation_check.md
28. bs_fix_reaudit_v1/double_benchmark_oracle_snf_check.md
29. bs_fix_reaudit_v1/double_diagnostic_kernel_vs_benchmark_alignment_report.md
30. bs_fix_reaudit_v1/group_engine_mode_report_194.1.1.1.md
31. bs_fix_reaudit_v1/group_engine_control_case_report_99.1.1.1.md
32. bs_fix_reaudit_v1/ai_vs_bilbao_alignment_report.md
33. bs_fix_reaudit_v1/p4_induction_failure_audit.md
34. bs_fix_reaudit_v1/p4_exact_solver_reliability_audit.md
35. bs_fix_reaudit_v1/p4_band_character_site_phase_decomposition.md
36. bs_fix_reaudit_v1/p4_trace_formula_vs_explicit_orbit_report.md
37. bs_fix_reaudit_v1/character_field_basis_convention_audit.md
38. bs_fix_reaudit_v1/sg194_setting_specific_character_conversion_validation.md
39. bs_fix_reaudit_v1/character_field_conversion_global_validation_report.md
40. bs_fix_reaudit_v1/p4_conversion_patch_independent_validation_report.md
41. bs_fix_reaudit_v1/claim_scope_guardrail_report.md
42. bs_fix_reaudit_v1/d3h_like_local_object_crosscheck.md
43. bs_fix_reaudit_v1/ppath06_residual_obstruction_audit.md
44. bs_fix_reaudit_v1/ppath06_row_semantics_report.md
45. bs_fix_reaudit_v1/ai_zero_subset_rank_report.md
46. bs_fix_reaudit_v1/partial_ai_lattice_witness_report.md
47. bs_fix_reaudit_v1/ai_honest_blocker_report.md

## PDF Report
- report file: `workflow_portability_report_194.1.1.1.pdf`
- report source: `workflow_portability_report_194.1.1.1.tex`
- recommended order: PDF first, then the JSON summaries and the audit markdown files
