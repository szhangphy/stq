# SG194 Remaining Cleanup v2

## generated_at

```json
"2026-04-01T12:27:55+08:00"
```

## tracked_delete_targets

```json
[
  "sg194/raw_194_1_1_1_single_ai_candidates.json",
  "sg194/raw_194_1_1_1_single_ai_basis.json",
  "sg194/raw_194_1_1_1_single_ai_in_bs_matrix.json",
  "sg194/raw_194_1_1_1_single_quotient.json",
  "sg194/sg194_single_direct_bs_derivation_v1.json",
  "sg194/sg194_single_direct_bs_derivation_v1.md",
  "sg194/sg194_single_direct_ai_derivation_v1.json",
  "sg194/sg194_single_direct_ai_derivation_v1.md",
  "sg194/sg194_single_direct_quotient_derivation_v1.json",
  "sg194/sg194_single_direct_quotient_derivation_v1.md",
  "sg194/sg194_single_direct_result_summary_v1.json",
  "sg194/sg194_single_direct_result_summary_v1.md",
  "sg194/review_package_sg194_single_direct_result_v1.tar.gz",
  "sg194/review_package_sg194_single_direct_result_v1/"
]
```

## git_deleted_paths

```json
[
  "sg194/raw_194_1_1_1_single_ai_basis.json",
  "sg194/raw_194_1_1_1_single_ai_candidates.json",
  "sg194/raw_194_1_1_1_single_ai_in_bs_matrix.json",
  "sg194/raw_194_1_1_1_single_quotient.json",
  "sg194/review_package_sg194_single_direct_result_v1.tar.gz",
  "sg194/review_package_sg194_single_direct_result_v1/README.md",
  "sg194/review_package_sg194_single_direct_result_v1/REVIEW_MAP.md",
  "sg194/review_package_sg194_single_direct_result_v1/benchmark_double_compare/current_status_1941111_benchmark_v1.json",
  "sg194/review_package_sg194_single_direct_result_v1/benchmark_double_compare/current_status_1941111_benchmark_v1.md",
  "sg194/review_package_sg194_single_direct_result_v1/benchmark_double_compare/sg194_benchmark_adoption_vs_internalization_v1.json",
  "sg194/review_package_sg194_single_direct_result_v1/benchmark_double_compare/sg194_benchmark_adoption_vs_internalization_v1.md",
  "sg194/review_package_sg194_single_direct_result_v1/cleanup/sg194_remaining_cleanup_v1.json",
  "sg194/review_package_sg194_single_direct_result_v1/cleanup/sg194_remaining_cleanup_v1.md",
  "sg194/review_package_sg194_single_direct_result_v1/inheritance_audit/sg194_single_inheritance_removal_audit_v1.json",
  "sg194/review_package_sg194_single_direct_result_v1/inheritance_audit/sg194_single_inheritance_removal_audit_v1.md",
  "sg194/review_package_sg194_single_direct_result_v1/single_direct_derivation/current_status_194.1.1.1_stage2.json",
  "sg194/review_package_sg194_single_direct_result_v1/single_direct_derivation/sg194_single_direct_ai_derivation_v1.json",
  "sg194/review_package_sg194_single_direct_result_v1/single_direct_derivation/sg194_single_direct_ai_derivation_v1.md",
  "sg194/review_package_sg194_single_direct_result_v1/single_direct_derivation/sg194_single_direct_bs_derivation_v1.json",
  "sg194/review_package_sg194_single_direct_result_v1/single_direct_derivation/sg194_single_direct_bs_derivation_v1.md",
  "sg194/review_package_sg194_single_direct_result_v1/single_direct_derivation/sg194_single_direct_quotient_derivation_v1.json",
  "sg194/review_package_sg194_single_direct_result_v1/single_direct_derivation/sg194_single_direct_quotient_derivation_v1.md",
  "sg194/review_package_sg194_single_direct_result_v1/single_direct_derivation/sg194_single_direct_result_summary_v1.json",
  "sg194/review_package_sg194_single_direct_result_v1/single_direct_derivation/sg194_single_direct_result_summary_v1.md",
  "sg194/sg194_single_direct_ai_derivation_v1.json",
  "sg194/sg194_single_direct_ai_derivation_v1.md",
  "sg194/sg194_single_direct_bs_derivation_v1.json",
  "sg194/sg194_single_direct_bs_derivation_v1.md",
  "sg194/sg194_single_direct_quotient_derivation_v1.json",
  "sg194/sg194_single_direct_quotient_derivation_v1.md",
  "sg194/sg194_single_direct_result_summary_v1.json",
  "sg194/sg194_single_direct_result_summary_v1.md"
]
```

## worktree_deleted_paths

```json
[]
```

## local_cleanup_targets_removed

```json
[
  "sg194/review_package_sg194_internalization_fix_v1",
  "sg194/review_package_sg194_internalization_fix_v1.tar.gz",
  "sg194/workflow_portability_report_stage2_194.1.1.1.aux",
  "sg194/workflow_portability_report_stage2_194.1.1.1.log",
  "sg194/workflow_portability_report_stage2_194.1.1.1.out"
]
```

## stale_single_direct_package_removed

```json
true
```
