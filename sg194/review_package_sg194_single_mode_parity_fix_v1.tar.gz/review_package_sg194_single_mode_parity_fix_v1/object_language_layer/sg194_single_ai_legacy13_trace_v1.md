# SG194 Single AI Legacy13 Trace v1

## generated_at

```json
"2026-04-01T12:27:55+08:00"
```

## target_group

```json
"194.1.1.1"
```

## legacy13_enters_active_single_ai_computation

```json
false
```

## legacy13_enters_reporting_only

```json
true
```

## active_single_ai_trace

```json
[
  {
    "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
    "source_function": "build_single_runtime",
    "step": "build the active 58x42 with-planes compatibility matrix and 16-dimensional BS basis"
  },
  {
    "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
    "source_function": "induce_objects",
    "step": "build 45 single-valued AI candidates directly in the active 42-row unknown ordering"
  },
  {
    "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
    "source_function": "bs_coordinate_matrix",
    "step": "convert the active 42-row candidate vectors into active BS coordinates and obtain rank 13"
  },
  {
    "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
    "source_function": "quotient_artifacts",
    "step": "compute the raw-current quotient directly from the same BS/AI presentation"
  }
]
```

## reporting_only_legacy13_trace

```json
[
  {
    "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
    "source_function": "apply_standard_projection_fields",
    "step": "inject the externally anchored 13/13/trivial projection into summary.final_rank_bs/final_rank_ai/quotient_group before the raw-current overwrite"
  },
  {
    "source_file": "sg194/debug_workflow_portability_stage2_194.1.1.1.py",
    "source_function": "apply_single_direct_result_fields",
    "step": "copy that projected 13/13/trivial layer into legacy_internal_projected_* provenance fields"
  },
  {
    "source_file": "sg194/debug_sg194_single_direct_result_v1.py",
    "source_function": "build_ai_payload",
    "step": "read current_stage2['single_legacy_internal_projected_rank_ai'] into legacy_auxiliary_projected_rank for reporting"
  }
]
```

## current_stage2_legacy_snapshot

```json
{
  "legacy_internal_projected_rank_bs": 13,
  "legacy_internal_projected_rank_ai": 13,
  "legacy_internal_projected_quotient_group": "trivial"
}
```

## verdict

```json
"Legacy-13 does not enter the active single AI computation path. It enters only through the historical externally anchored projection payload and then survives as provenance in stage2 / reporting fields."
```
